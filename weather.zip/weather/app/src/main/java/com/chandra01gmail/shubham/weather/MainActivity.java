package com.chandra01gmail.shubham.weather;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

//92635e5afa7fc3ac

public class MainActivity extends AppCompatActivity {

    public  String key = "http://api.wunderground.com/api/92635e5afa7fc3ac/conditions/q/IN/";

    EditText a;
    TextView b ;
    String ss;
    String ss1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onFind(View v)
    {
        if(R.id.btn==v.getId())
        {
            a=(EditText)findViewById(R.id.tv1);
            String c = a.getText().toString();
            if(c.isEmpty())
            {
                Toast.makeText(MainActivity.this, "Please enter a city name", Toast.LENGTH_SHORT).show();
                return ;
            }
            else
            {
                ss =key;
                ss1 = c;
                c += ".json";
                ss += c;
                RequestQueue queue = Volley.newRequestQueue(this);
                StringRequest stringRequest = new StringRequest(Request.Method.GET,ss, new Response.Listener<String>()
                {
                    @Override
                    // on successfull response
                    public void onResponse(String response) {
                        try {
                            JSONObject weather = new JSONObject(response);
                            JSONObject obs = weather.getJSONObject("current_observation");
                            String temp = Integer.toString(obs.getInt("temp_c"));
                            String humidity = obs.getString("relative_humidity");
                            String wind_speed = Integer.toString(obs.getInt("wind_kph"));
                            String visibility = obs.getString("visibility_km");
                            String wind_direction = obs.getString("wind_dir");
                            String wea = obs.getString("weather");


                           String ans = "";
                            ans+=(ss1.toUpperCase()+"\n\n\n"+"Temperature :    "+temp+" C\n"+"Humidity :    "+humidity+"\n"+"Wind Speed :    "+wind_speed+" km/hr\n"+
                                    "Wind Direction :    "+wind_direction+"\n"+"Visibility :    "+visibility+" km/hr\n"+"Weather :    "+wea+"\n");
                            b = (TextView) findViewById(R.id.tv2);
                            b.setText(ans);

                        }catch (Exception e){}
                    }

                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Check your connection!!", Toast.LENGTH_SHORT).show();

                    }
                });

                stringRequest.setRetryPolicy(new DefaultRetryPolicy(DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 2, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                queue.add(stringRequest);



            }
        }
    }
}
